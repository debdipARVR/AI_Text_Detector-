# arXiv / TechRxiv / Zenodo Preprint Submission Bundle

## Paper Title:
Multi-Pass Sentence Cloze Infilling with Sigmoidal Semantic Congruence for Robust AI Text Detection

## Author:
Debdip Bandyopadhyay (Independent Researcher)
Email: debdip1992@outlook.com
GitHub: https://github.com/debdipARVR/AI_Text_Detector-

## Files Included:
- `paper.pdf`: Publication-ready compiled PDF manuscript.
- `paper.tex`: Main LaTeX source document (IEEEtran format).
- `references.bib`: Complete BibTeX bibliography with citations.
- `data/benchmark_results.json`: Empirical evaluation logs across 6 academic domains.

## How to Submit:
1. **Overleaf**: Go to https://overleaf.com -> 'New Project' -> 'Upload Project' -> Upload `arxiv_preprint_bundle.zip`.
2. **arXiv (cs.CL / cs.AI)**: Go to https://arxiv.org/submit -> Upload `paper.tex` and `references.bib`.
3. **TechRxiv**: Upload PDF compiled from Overleaf to https://www.techrxiv.org.
